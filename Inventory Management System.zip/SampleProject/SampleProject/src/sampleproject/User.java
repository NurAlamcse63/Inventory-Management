
package sampleproject;

/**
 *
 * @author hp
 */
public class User {
    
    private int id;
    private String name;
    private String price;
    private String category;
    
    
    public User(int id,String name,String price, String category)
    {
        this.id = id;
        this.name = name;
        this.price = price;
        this.category = category;
    }
    
    public int getid()
    {
        return id;
    }
    
    public String getname()
    {
        return name;
    }
    
    public String getprice()
    {
        return price;
    }
    
    public String getcategory()
    {
        return category;
    }
}
