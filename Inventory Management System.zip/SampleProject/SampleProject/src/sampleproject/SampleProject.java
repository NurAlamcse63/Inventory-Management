package sampleproject;

public class SampleProject {

    public static void main(String[] args) {
        new sampleForm().setVisible(true);
    }
    
}
